package eus.ehu.final2;

public class Status {

    public Status reblog;
    String id;
    String content;

    Account account;
    public String created_at;
    public static class Account{

        String username;
    }
}
